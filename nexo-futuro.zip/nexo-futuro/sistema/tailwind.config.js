/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        primary: {
          DEFAULT: '#98D87C',
          hover: '#7FC164',
        },
        inst: {
          blue: '#2563EB',
          dark: '#1E3A8A',
        },
        gray: {
          prof: '#374151',
          dark: '#1F2937',
        },
        feedback: {
          success: '#10B981',
          error: '#EF4444',
          warning: '#F59E0B',
          info: '#38BDF8',
        }
      },
      fontFamily: {
        sans: ['Inter', 'sans-serif'],
      }
    },
  },
  plugins: [],
}
