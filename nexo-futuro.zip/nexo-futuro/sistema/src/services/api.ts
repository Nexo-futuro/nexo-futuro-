// API Base URL - Replace with your actual API endpoint
const API_BASE_URL = "https://sua-api.com/api";

// Generic fetch wrapper with error handling
async function fetchAPI<T>(
  endpoint: string,
  options?: RequestInit
): Promise<T> {
  try {
    const response = await fetch(`${API_BASE_URL}${endpoint}`, {
      headers: {
        "Content-Type": "application/json",
        ...options?.headers,
      },
      ...options,
    });

    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }

    return await response.json();
  } catch (error) {
    console.error("API Error:", error);
    throw error;
  }
}

// Usuario API
export const usuarioAPI = {
  list: () => fetchAPI("/usuarios"),
  getById: (id: number) => fetchAPI(`/usuarios/${id}`),
  create: (data: any) =>
    fetchAPI("/usuarios", {
      method: "POST",
      body: JSON.stringify(data),
    }),
  update: (id: number, data: any) =>
    fetchAPI(`/usuarios/${id}`, {
      method: "PUT",
      body: JSON.stringify(data),
    }),
  delete: (id: number) =>
    fetchAPI(`/usuarios/${id}`, {
      method: "DELETE",
    }),
};

// Mentoria API
export const mentoriaAPI = {
  list: () => fetchAPI("/mentorias"),
  getById: (id: number) => fetchAPI(`/mentorias/${id}`),
  create: (data: any) =>
    fetchAPI("/mentorias", {
      method: "POST",
      body: JSON.stringify(data),
    }),
  update: (id: number, data: any) =>
    fetchAPI(`/mentorias/${id}`, {
      method: "PUT",
      body: JSON.stringify(data),
    }),
  delete: (id: number) =>
    fetchAPI(`/mentorias/${id}`, {
      method: "DELETE",
    }),
};

// Contato API
export const contatoAPI = {
  send: (data: { nome: string; email: string; assunto: string; mensagem: string }) =>
    fetchAPI("/contato", {
      method: "POST",
      body: JSON.stringify(data),
    }),
};
