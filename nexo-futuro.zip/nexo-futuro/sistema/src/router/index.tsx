import React from 'react';
import { createBrowserRouter, RouterProvider } from 'react-router-dom';
import MainLayout from '../layout/MainLayout';
import Home from '../paginas/Home';
import Integrantes from '../paginas/Integrantes';
import Sobre from '../paginas/Sobre';
import FAQ from '../paginas/FAQ';
import Contato from '../paginas/Contato';

// Placeholder components for routes not yet implemented
const Placeholder = ({ title }: { title: string }) => (
  <div className="flex flex-col items-center justify-center min-h-[60vh] text-center px-4">
    <h1 className="text-3xl font-bold text-gray-800 mb-4">{title}</h1>
    <p className="text-gray-600">Esta página está em construção.</p>
  </div>
);

const router = createBrowserRouter([
  {
    path: '/',
    element: <MainLayout />,
    children: [
      {
        index: true,
        element: <Home />,
      },
      {
        path: 'integrantes',
        element: <Integrantes />,
      },
      {
        path: 'sobre',
        element: <Sobre />,
      },
      {
        path: 'faq',
        element: <FAQ />,
      },
      {
        path: 'contato',
        element: <Contato />,
      },
      {
        path: 'usuarios',
        children: [
          { index: true, element: <Placeholder title="Gestão de Usuários" /> },
          { path: ':id', element: <Placeholder title="Detalhes do Usuário" /> },
        ]
      },
      {
        path: 'mentorias',
        children: [
          { index: true, element: <Placeholder title="Gestão de Mentorias" /> },
          { path: ':id', element: <Placeholder title="Detalhes da Mentoria" /> },
        ]
      },
    ],
  },
]);

export const AppRouter = () => {
  return <RouterProvider router={router} />;
};
