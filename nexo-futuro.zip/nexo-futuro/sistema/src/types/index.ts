export type Perfil = "gestor" | "mentor" | "colaborador";

export interface Competencia {
  id: number;
  nome: string;
  nivel: number;
}

export interface Usuario {
  id: number;
  nome: string;
  email: string;
  role: Perfil;
  foto?: string;
  rm?: string;
  turma?: string;
}

export type UsuarioCompleto = Usuario & { competencias: Competencia[] };

export interface Mentoria {
  id: number;
  titulo: string;
  mentorId: number;
  mentorNome: string;
  data: string;
  status: 'agendada' | 'concluida' | 'cancelada';
}
