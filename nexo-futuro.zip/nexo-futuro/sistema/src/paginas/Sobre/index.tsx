import React from "react";
import {Target, TrendingUp, Users, Database, Code, Zap} from 'lucide-react';

const Sobre = () => {
  const beneficios = [
    { icon: TrendingUp, title: "Redução de turnover", description: "Colaboradores mais engajados permanecem na empresa" },
    { icon: Users, title: "Aumento do engajamento", description: "Equipes mais motivadas e produtivas" },
    { icon: Zap, title: "Maior eficiência", description: "Desenvolvimento humano estruturado e mensurável" },
    { icon: Target, title: "Tomada de decisão", description: "Insights baseados em dados reais" },
  ];

  return (
    <div className="min-h-screen bg-white">
      {/* Hero Section */}
      <div className="bg-gradient-to-r from-[#1E3A8A] to-[#2563EB] text-white py-16 px-4 sm:px-6 lg:px-8">
        <div className="max-w-4xl mx-auto text-center">
          <h1 className="text-4xl md:text-5xl font-bold mb-6">Sobre o Nexo Futuro</h1>
          <p className="text-xl md:text-2xl text-blue-100">
            Conectando pessoas, construindo desenvolvimento humano
          </p>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-6xl mx-auto py-12 px-4 sm:px-6 lg:px-8">
        {/* Introduction */}
        <div className="mb-16">
          <p className="text-lg text-gray-700 leading-relaxed mb-6">
            O <span className="font-bold text-[#2563EB]">Nexo Futuro</span> é uma plataforma corporativa desenvolvida para impulsionar o crescimento profissional dentro das organizações por meio de conexões humanas inteligentes. A solução une tecnologia, análise de dados e estratégias de desenvolvimento interpessoal para criar programas de mentoria estruturados, personalizados e altamente eficientes.
          </p>
          <p className="text-lg text-gray-700 leading-relaxed mb-6">
            O sistema foi projetado para atender empresas que desejam aprimorar competências internas, fortalecer o engajamento de equipes e promover uma cultura contínua de aprendizado. Por meio da plataforma, gestores, colaboradores e mentores podem participar de mentorias orientadas, feedbacks 360°, avaliações formais e trilhas de crescimento baseadas em competências reais.
          </p>
        </div>

        {/* Architecture */}
        <div className="mb-16">
          <h2 className="text-3xl font-bold text-gray-800 mb-8 text-center">Arquitetura da Solução</h2>
          <div className="grid md:grid-cols-2 gap-8">
            <div className="bg-white border border-gray-200 rounded-xl p-8 shadow-md">
              <div className="flex items-center mb-4">
                <div className="w-12 h-12 bg-[#2563EB] rounded-lg flex items-center justify-center mr-4">
                  <Code className="w-6 h-6 text-white" />
                </div>
                <h3 className="text-xl font-bold text-gray-800">Frontend</h3>
              </div>
              <p className="text-gray-600 mb-4">
                Interface moderna e responsiva desenvolvida em <span className="font-semibold">React + TypeScript</span>
              </p>
              <ul className="space-y-2 text-sm text-gray-600">
                <li>• Vite para build otimizado</li>
                <li>• TailwindCSS para estilização</li>
                <li>• React Router para navegação SPA</li>
                <li>• Design mobile-first</li>
              </ul>
            </div>

            <div className="bg-white border border-gray-200 rounded-xl p-8 shadow-md">
              <div className="flex items-center mb-4">
                <div className="w-12 h-12 bg-[#1E3A8A] rounded-lg flex items-center justify-center mr-4">
                  <Database className="w-6 h-6 text-white" />
                </div>
                <h3 className="text-xl font-bold text-gray-800">Backend</h3>
              </div>
              <p className="text-gray-600 mb-4">
                API robusta e escalável construída com <span className="font-semibold">Java + Quarkus</span>
              </p>
              <ul className="space-y-2 text-sm text-gray-600">
                <li>• RESTful API completa</li>
                <li>• Autenticação segura</li>
                <li>• Matching automático de mentorias</li>
                <li>• Relatórios e dashboards</li>
              </ul>
            </div>
          </div>
        </div>

        {/* Benefits */}
        <div className="mb-16">
          <h2 className="text-3xl font-bold text-gray-800 mb-8 text-center">Benefícios Corporativos</h2>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {beneficios.map((beneficio, index) => (
              <div
                key={index}
                className="bg-white border border-[#98D87C] rounded-xl p-6 text-center hover:shadow-lg transition-shadow duration-300"
              >
                <div className="w-16 h-16 bg-gradient-to-br from-[#98D87C] to-[#7FC164] rounded-full flex items-center justify-center mx-auto mb-4">
                  <beneficio.icon className="w-8 h-8 text-white" />
                </div>
                <h3 className="font-bold text-gray-800 mb-2">{beneficio.title}</h3>
                <p className="text-sm text-gray-600">{beneficio.description}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Mentorship Flow */}
        <div className="mb-16">
          <h2 className="text-3xl font-bold text-gray-800 mb-8 text-center">Fluxo de Funcionamento da Mentoria</h2>
          <div className="bg-gradient-to-br from-blue-50 to-green-50 rounded-xl p-8">
            <div className="space-y-6">
              <div className="flex items-start">
                <div className="w-10 h-10 bg-[#2563EB] text-white rounded-full flex items-center justify-center font-bold mr-4 flex-shrink-0">
                  1
                </div>
                <div>
                  <h4 className="font-bold text-gray-800 mb-1">Cadastro de Perfis</h4>
                  <p className="text-gray-600">Gestores, mentores e colaboradores registram suas competências e objetivos na plataforma.</p>
                </div>
              </div>
              <div className="flex items-start">
                <div className="w-10 h-10 bg-[#2563EB] text-white rounded-full flex items-center justify-center font-bold mr-4 flex-shrink-0">
                  2
                </div>
                <div>
                  <h4 className="font-bold text-gray-800 mb-1">Matching Inteligente</h4>
                  <p className="text-gray-600">O sistema analisa perfis e sugere as melhores conexões entre mentores e mentorados.</p>
                </div>
              </div>
              <div className="flex items-start">
                <div className="w-10 h-10 bg-[#2563EB] text-white rounded-full flex items-center justify-center font-bold mr-4 flex-shrink-0">
                  3
                </div>
                <div>
                  <h4 className="font-bold text-gray-800 mb-1">Agendamento e Acompanhamento</h4>
                  <p className="text-gray-600">Mentorias são agendadas e o progresso é monitorado através de feedbacks e avaliações.</p>
                </div>
              </div>
              <div className="flex items-start">
                <div className="w-10 h-10 bg-[#2563EB] text-white rounded-full flex items-center justify-center font-bold mr-4 flex-shrink-0">
                  4
                </div>
                <div>
                  <h4 className="font-bold text-gray-800 mb-1">Análise e Resultados</h4>
                  <p className="text-gray-600">Dashboards fornecem insights sobre o desenvolvimento e ROI das mentorias.</p>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Mission Statement */}
        <div className="bg-gradient-to-r from-[#1E3A8A] to-[#2563EB] rounded-xl p-8 md:p-12 text-white text-center">
          <p className="text-xl md:text-2xl font-semibold leading-relaxed">
            Somos a ponte entre pessoas, tecnologia e evolução profissional — construindo o futuro das organizações através da força das conexões humanas.
          </p>
        </div>
      </div>
    </div>
  );
};

export default Sobre;
