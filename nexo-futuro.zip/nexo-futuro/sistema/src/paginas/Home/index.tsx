import React from "react";
import {
  ArrowRight,
  Users,
  BookOpen,
  BarChart2,
  MessageSquare,
  Star,
} from "lucide-react";
import { Link } from "react-router-dom";

const Home = () => {
  return (
    <div className="flex flex-col">
      {/* Hero Section */}
      <section className="relative bg-inst-dark text-white overflow-hidden">
        <div className="absolute inset-0 bg-black/20 z-10"></div>

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24 relative z-20 flex flex-col md:flex-row items-center">
          <div className="md:w-1/2 text-center md:text-left mb-10 md:mb-0">
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold leading-tight mb-6">
              Conectando pessoas, <br />
              <span className="text-primary">construindo desenvolvimento humano.</span>
            </h1>

            <p className="text-lg text-gray-200 mb-8 max-w-xl mx-auto md:mx-0">
              Uma plataforma integrada para gestão de talentos, mentorias e crescimento profissional.
            </p>

            <Link
              to="/usuarios"
              className="inline-flex items-center px-8 py-3 border border-transparent text-base font-medium rounded-md text-gray-900 bg-primary hover:bg-primary-hover transition-colors duration-300 shadow-lg hover:shadow-xl transform hover:-translate-y-1"
            >
              Acessar Plataforma
              <ArrowRight className="ml-2 h-5 w-5" />
            </Link>
          </div>

          <div className="md:w-1/2 flex justify-center">
            <img
              src="https://static.lumi.new/ea/ea980a621bcc1cd25ad7953b61bba3d6.jpeg"
              alt="Nexo Futuro Concept"
              className="w-full max-w-md rounded-2xl shadow-2xl border-4 border-white/10 backdrop-blur-sm"
              id="hero-image"
            />
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-gray-prof mb-4">Nossas Áreas</h2>
            <p className="text-gray-600 max-w-2xl mx-auto">
              Explore as funcionalidades projetadas para potencializar o desenvolvimento da sua equipe.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <FeatureCard
              icon={Users}
              title="Gestão de Usuários"
              description="Administre colaboradores, mentores e gestores em um único lugar."
              link="/usuarios"
            />

            <FeatureCard
              icon={BookOpen}
              title="Mentorias"
              description="Conecte mentores e mentorados para troca de conhecimento."
              link="/mentorias"
            />

            <FeatureCard
              icon={Star}
              title="Competências"
              description="Mapeie e desenvolva as hard e soft skills do time."
              link="#"
            />

            <FeatureCard
              icon={BarChart2}
              title="Dashboard"
              description="Visualize métricas de crescimento e engajamento."
              link="#"
            />

            <FeatureCard
              icon={MessageSquare}
              title="Feedback"
              description="Canal aberto para avaliações e melhoria contínua."
              link="#"
            />
          </div>
        </div>
      </section>
    </div>
  );
};

interface FeatureCardProps {
  icon: React.ElementType;
  title: string;
  description: string;
  link: string;
}

const FeatureCard = ({ icon: Icon, title, description, link }: FeatureCardProps) => (
  <Link to={link} className="group">
    <div className="bg-white rounded-xl p-8 shadow-md border border-green-100 hover:shadow-lg hover:border-primary transition-all duration-300 h-full flex flex-col items-center text-center md:items-start md:text-left">
      <div className="p-3 rounded-full bg-blue-50 text-inst-blue mb-4 group-hover:bg-primary group-hover:text-white transition-colors duration-300">
        <Icon className="w-8 h-8" />
      </div>

      <h3 className="text-xl font-bold text-gray-800 mb-2 group-hover:text-inst-blue transition-colors">
        {title}
      </h3>

      <p className="text-gray-600">{description}</p>
    </div>
  </Link>
);

export default Home;
