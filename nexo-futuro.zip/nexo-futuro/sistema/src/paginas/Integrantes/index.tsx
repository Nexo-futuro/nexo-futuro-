import React from "react";
import { User } from 'lucide-react';

interface Integrante {
  nome: string;
  rm: string;
  turma: string;
  avatar?: string;
}

const integrantes: Integrante[] = [
  {
    nome: "Gustavo Cordeiro de Souza",
    rm: "565514",
    turma: "1TDSPO-2025",
    avatar: "/../public/img/gustavo.jpg",  // Caminho absoluto
  },
  {
    nome: "Pedro dos Anjos Viana Moraes",
    rm: "563832",
    turma: "1TDSPO-2025",
    avatar: "/../public/img/pedro.jpg",    // Caminho absoluto
  },
];




const Integrantes = () => {
  return (
    <div className="min-h-screen bg-white py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-gray-800 mb-4">Nossa Equipe</h1>
          <p className="text-lg text-gray-600">
            Conheça os integrantes responsáveis pelo desenvolvimento do Nexo Futuro
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-2 gap-8 max-w-4xl mx-auto">
          {integrantes.map((integrante, index) => (
            <div
              key={index}
              className="bg-white border border-[#98D87C] rounded-xl shadow-md p-8 hover:shadow-lg transition-shadow duration-300"
            >
              <div className="flex flex-col items-center text-center">
                <div className="w-24 h-24 bg-gradient-to-br from-[#98D87C] to-[#7FC164] rounded-full flex items-center justify-center mb-4">
                  {integrante.avatar ? (
                    <img
                      src={integrante.avatar}
                      alt={integrante.nome}
                      className="w-full h-full rounded-full object-cover"
                    />
                  ) : (
                    <User className="w-12 h-12 text-white" />
                  )}
                </div>
                <h2 className="text-xl font-bold text-gray-800 mb-2">
                  {integrante.nome}
                </h2>
                <div className="space-y-1 text-gray-600">
                  <p className="text-sm">
                    <span className="font-semibold">RM:</span> {integrante.rm}
                  </p>
                  <p className="text-sm">
                    <span className="font-semibold">Turma:</span> {integrante.turma}
                  </p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Integrantes;
