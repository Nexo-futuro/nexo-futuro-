/* eslint-disable react-refresh/only-export-components */
import React, { useState } from "react";
import {ChevronDown, ChevronUp} from 'lucide-react';

interface FAQItem {
  pergunta: string;
  resposta: string;
}

const faqData: FAQItem[] = [
  {
    pergunta: "O que é o Nexo Futuro?",
    resposta: "Plataforma corporativa de desenvolvimento humano que conecta mentores e colaboradores com foco em crescimento profissional.",
  },
  {
    pergunta: "Quais recursos a plataforma oferece?",
    resposta: "Gestão de usuários, mentorias, feedback 360°, dashboard de métricas e sistema de competências.",
  },
  {
    pergunta: "Como funciona o matching de mentorias?",
    resposta: "A API realiza o cruzamento entre perfis, competências e necessidades para sugerir a melhor conexão.",
  },
  {
    pergunta: "Quais benefícios a empresa obtém?",
    resposta: "Redução de turnover, aumento de engajamento e economia em treinamentos.",
  },
  {
    pergunta: "A plataforma possui dashboard e relatórios?",
    resposta: "Sim, a solução gera relatórios, métricas e insights do desenvolvimento dos colaboradores.",
  },
];

const FAQ = () => {
  const [openIndex, setOpenIndex] = useState<number | null>(null);

  const toggleFAQ = (index: number) => {
    setOpenIndex(openIndex === index ? null : index);
  };

  return (
    <div className="min-h-screen bg-white py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-gray-800 mb-4">Perguntas Frequentes</h1>
          <p className="text-lg text-gray-600">
            Tire suas dúvidas sobre o Nexo Futuro
          </p>
        </div>

        <div className="space-y-4">
          {faqData.map((item, index) => (
            <div
              key={index}
              className="bg-white border border-gray-200 rounded-xl shadow-md overflow-hidden transition-all duration-300 hover:shadow-lg"
            >
              <button
                onClick={() => toggleFAQ(index)}
                className="w-full px-6 py-5 text-left flex items-center justify-between hover:bg-gray-50 transition-colors duration-200"
              >
                <span className="font-semibold text-gray-800 text-lg pr-8">
                  {item.pergunta}
                </span>
                <span className="flex-shrink-0">
                  {openIndex === index ? (
                    <ChevronUp className="w-6 h-6 text-[#98D87C]" />
                  ) : (
                    <ChevronDown className="w-6 h-6 text-gray-400" />
                  )}
                </span>
              </button>
              
              <div
                className={`overflow-hidden transition-all duration-300 ${
                  openIndex === index ? "max-h-96" : "max-h-0"
                }`}
              >
                <div className="px-6 py-4 bg-gray-50 border-t border-gray-200">
                  <p className="text-gray-700 leading-relaxed">{item.resposta}</p>
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="mt-12 bg-gradient-to-r from-[#1E3A8A] to-[#2563EB] rounded-xl p-8 text-white text-center">
          <h3 className="text-2xl font-bold mb-3">Ainda tem dúvidas?</h3>
          <p className="mb-6">Entre em contato conosco para mais informações</p>
          <a
            href="/contato"
            className="inline-block bg-[#98D87C] hover:bg-[#7FC164] text-white font-semibold px-8 py-3 rounded-lg transition-colors duration-200"
          >
            Fale Conosco
          </a>
        </div>
      </div>
    </div>
  );
};

export default FAQ;
