import React, { useState, FormEvent } from "react";
import { Mail, User, MessageSquare, Send } from "lucide-react";

interface FormData {
  nome: string;
  email: string;
  assunto: string;
  mensagem: string;
}

const Contato = () => {
  const [formData, setFormData] = useState<FormData>({
    nome: "",
    email: "",
    assunto: "",
    mensagem: "",
  });

  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState<{ type: "success" | "error"; text: string } | null>(null);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setMessage(null);

    try {
      const response = await fetch("https://sua-api.com/api/contato", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(formData),
      });

      if (!response.ok) {
        throw new Error("Erro ao enviar mensagem");
      }

      setMessage({
        type: "success",
        text: "Mensagem enviada com sucesso! Entraremos em contato em breve.",
      });

      setFormData({ nome: "", email: "", assunto: "", mensagem: "" });
    } catch {
      setMessage({
        type: "error",
        text: "Erro ao enviar mensagem. Por favor, tente novamente.",
      });
    } finally {
      setLoading(false);
    }
  }; // <-- ESTA CHAVE FALTAVA

  return (
    <div className="min-h-screen bg-white py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-3xl mx-auto">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-gray-800 mb-4">Entre em Contato</h1>
          <p className="text-lg text-gray-600">
            Entre em contato conosco para suporte, dúvidas ou solicitações sobre a plataforma Nexo Futuro.
          </p>
        </div>

        <div className="bg-white border border-gray-200 rounded-xl shadow-md p-8">
          <form onSubmit={handleSubmit} className="space-y-6">

            {/* Nome */}
            <div>
              <label htmlFor="nome" className="block text-sm font-semibold text-gray-700 mb-2">
                Nome
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <User className="h-5 w-5 text-gray-400" />
                </div>
                <input
                  type="text"
                  id="nome"
                  name="nome"
                  value={formData.nome}
                  onChange={handleChange}
                  required
                  className="block w-full pl-10 pr-3 py-3 border border-gray-300 rounded-lg
                             focus:ring-2 focus:ring-[#98D87C] focus:border-transparent transition-colors"
                  placeholder="Seu nome completo"
                />
              </div>
            </div>

            {/* Email */}
            <div>
              <label htmlFor="email" className="block text-sm font-semibold text-gray-700 mb-2">
                E-mail
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <Mail className="h-5 w-5 text-gray-400" />
                </div>
                <input
                  type="email"
                  id="email"
                  name="email"
                  value={formData.email}
                  onChange={handleChange}
                  required
                  className="block w-full pl-10 pr-3 py-3 border border-gray-300 rounded-lg 
                             focus:ring-2 focus:ring-[#98D87C] focus:border-transparent transition-colors"
                  placeholder="seu@email.com"
                />
              </div>
            </div>

            {/* Assunto */}
            <div>
              <label htmlFor="assunto" className="block text-sm font-semibold text-gray-700 mb-2">
                Assunto
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                  <MessageSquare className="h-5 w-5 text-gray-400" />
                </div>
                <input
                  type="text"
                  id="assunto"
                  name="assunto"
                  value={formData.assunto}
                  onChange={handleChange}
                  required
                  className="block w-full pl-10 pr-3 py-3 border border-gray-300 rounded-lg
                             focus:ring-2 focus:ring-[#98D87C] focus:border-transparent transition-colors"
                  placeholder="Assunto da mensagem"
                />
              </div>
            </div>

            {/* Mensagem */}
            <div>
              <label htmlFor="mensagem" className="block text-sm font-semibold text-gray-700 mb-2">
                Mensagem
              </label>
              <textarea
                id="mensagem"
                name="mensagem"
                value={formData.mensagem}
                onChange={handleChange}
                required
                rows={6}
                className="block w-full px-3 py-3 border border-gray-300 rounded-lg
                           focus:ring-2 focus:ring-[#98D87C] focus:border-transparent 
                           transition-colors resize-none"
                placeholder="Escreva sua mensagem aqui..."
              />
            </div>

            {/* Mensagem de retorno */}
            {message && (
              <div
                className={`p-4 rounded-lg ${
                  message.type === "success"
                    ? "bg-green-50 text-green-800 border border-green-200"
                    : "bg-red-50 text-red-800 border border-red-200"
                }`}
              >
                {message.text}
              </div>
            )}

            {/* Botão */}
            <button
              type="submit"
              disabled={loading}
              className="w-full bg-[#98D87C] hover:bg-[#7FC164] text-white font-semibold py-3 px-6 
                         rounded-lg transition-colors duration-200 flex items-center justify-center gap-2 
                         disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {loading ? (
                "Enviando..."
              ) : (
                <>
                  <Send className="w-5 h-5" />
                  Enviar Mensagem
                </>
              )}
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};

export default Contato;
